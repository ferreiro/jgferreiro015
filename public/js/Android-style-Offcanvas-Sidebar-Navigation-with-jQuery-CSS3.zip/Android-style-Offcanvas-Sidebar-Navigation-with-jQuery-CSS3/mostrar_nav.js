$('#mobile-nav').click(function(event) {
  $('nav').toggleClass('active');
});
